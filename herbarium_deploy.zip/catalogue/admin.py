from django.contrib import admin
from .models import Species

@admin.register(Species)
class SpeciesAdmin(admin.ModelAdmin):
    list_display = ('genus', 'species', 'family', 'barcode', 'country', 'is_cultivated')
    search_fields = ('genus', 'species', 'family', 'barcode')
    list_filter = ('family', 'country', 'major_taxon_group', 'is_cultivated')
