document.getElementById('search-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const searchParams = new URLSearchParams(formData);

    fetch(`/api/search/?${searchParams.toString()}`)
        .then(response => response.json())
        .then(data => {
            const resultsArea = document.getElementById('results-area');
            const noResults = document.getElementById('no-results');

            resultsArea.innerHTML = ''; // Clear previous results

            if (data.results.length === 0) {
                noResults.classList.remove('hidden');
            } else {
                noResults.classList.add('hidden');

                data.results.forEach(plant => {
                    const card = document.createElement('div');
                    card.className = 'plant-card';

                    const imageUrl = plant.image_url || 'https://placehold.co/400x300/e8f5e9/2e7d32?text=No+Image';

                    card.innerHTML = `
                        <img src="${imageUrl}" alt="${plant.genus} ${plant.species}" class="plant-image">
                        <div class="plant-info">
                            <div class="plant-title">${plant.genus} ${plant.species}</div>
                            <div class="plant-detail">Family: ${plant.family}</div>
                            <div class="plant-detail">Barcode: ${plant.barcode}</div>
                            <div class="plant-detail">Country: ${plant.country || 'N/A'}</div>
                        </div>
                    `;

                    resultsArea.appendChild(card);
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Something went wrong with the search! 🥀");
        });
});
